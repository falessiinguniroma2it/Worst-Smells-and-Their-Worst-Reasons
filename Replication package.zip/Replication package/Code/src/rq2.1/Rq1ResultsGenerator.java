package rq1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.*;

import static java.lang.System.exit;

public class Rq1ResultsGenerator {
    private List<FileData> fileDatum = new ArrayList<>();
    private Iterator files = DataParser.getIterator();
    private RuleGroups rules = new RuleGroups();

    public void analyzeData() {
        BufferedReader in;
        PrintWriter writer;

        try {
            writer = new PrintWriter("rq1/Rq1Results.csv", "UTF-8");
            writer.println("Project ID,Group ID,Average Value,Value Standard Deviation");

            int start = 18, stop = 332;
            double avg, std;
            List<String> rulesList = rules.getRulesList();
            List<Double> sumList;
            while (files.hasNext()) {
                // Analyze file csvFileData
                String fileName = (String)files.next();
                System.out.println(fileName);
                in = new BufferedReader(new FileReader(new File("csvFileData/" + fileName + ".csv")));

                String line = in.readLine(); // skips headers
                FileData data = new FileData(fileName, line.split(","));
                while ((line = in.readLine()) != null) {
                    String[] splitLine = line.split(",");
                    for (int i = start; i <= stop; i++) {
                        data.add(rulesList.get(i - 18), splitLine[i]);
                    }
                }

                // Write Yes Group
                sumList = new ArrayList<>();
                for (String rule : rules.getRuleGroups().get("yes")) {
                    sumList.add(data.getSum(rule));
                }
                avg = calcAverage(sumList);
                std = calculateSTD(sumList, avg);
                writer.println(data.name + ",yes," + avg + "," + std);

                // Write No Group
                sumList = new ArrayList<>();
                for (String rule : rules.getRuleGroups().get("no")) {
                    sumList.add(data.getSum(rule));
                }
                avg = calcAverage(sumList);
                std = calculateSTD(sumList, avg);
                writer.println(data.name + ",no," + avg + "," + std);

            }

            writer.close();
        } catch (Exception e) {
            System.out.println("Error analyzing csvFileData and writing results");
            System.out.println(e);
            exit(1);
        }
    }

    private double calcAverage(List<Double> values) {
        double sum = 0.0;

        for(Double num : values) {
            sum += num;
        }

        return sum/values.size();
    }

    private double calculateSTD(List<Double> values, Double mean) {
        double std = 0.0;

        for(Double num: values) {
            std += Math.pow(num - mean, 2);
        }

        return Math.sqrt(std/values.size());
    }

    private class FileData {
        public String name;
        public ArrayList<String> headers;
        public Map<String, List<Double>> codeSmells = new HashMap<>();

        public FileData(String name, String[] headers) {
            this.name = name;
            this.headers = new ArrayList<String>(Arrays.asList(headers));
        }

        public void add(String rule, String numSmells) {
            if (!codeSmells.containsKey(rule)) {
                codeSmells.put(rule, new ArrayList<>());
            }
            double val = Double.valueOf(numSmells.substring(1, numSmells.length() - 1));
            codeSmells.get(rule).add(Double.valueOf(val));
        }

        public double getSum(String rule) {
            double sum = 0.0;
            for (Double num : codeSmells.get(rule)) {
                sum += num;
            }
            return sum;
        }
    }

}