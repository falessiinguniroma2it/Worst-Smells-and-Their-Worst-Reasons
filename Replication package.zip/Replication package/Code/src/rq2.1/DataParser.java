package rq1;

import java.util.*;

public class DataParser {
    private static final List<String> files = new ArrayList<>(Arrays.asList(
            "apexDDM",
            "ariesjpaDDMTable",
            "avroDDMTable",
            "axiomDDMTable",
            "bigtopDDM",
            "calciteDDM",
            "commonsDaemonDDMTable",
            "commonsJexlDDMTable",
            "deltaSpikeddmTable",
            "fileUploadDDMTable",
            "fileUploadDDMTable",
            "helixDDMTable",
            "httpDDMTable",
            "JCSDDM",
            "langDDMTable",
            "loggingDDMTable",
            "mahoutDDMTable",
            "mathDDM",
            "minaDDM",
            "netDDM",
            "olingoDDMTable",
            "openMeetingsDDMTable",
            "poolDDM",
            "rollerDDMTable",
            "stormDDMTable",
            "tikaDDMTable",
            "tobagoDDMTable",
            "velocityDDMTable"
    ));

    public static Iterator<String> getIterator() {
        return files.iterator();
    }
}
