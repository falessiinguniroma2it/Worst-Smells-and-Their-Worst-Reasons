import initialScript.FinalResultsTranslator;
import initialScript.Parser;
import initialScript.ResultsStore;
import rq1.Rq1ResultsGenerator;
import rq2.Rq2ResultsGenerator;
import rq3.Rq3ResultsGenerator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

import static java.lang.System.exit;

public class ScriptRunner {
    public static void main(String[] args) {
        int scriptNum = Integer.valueOf(args[0]);

        switch(scriptNum) {
            case (0):
                initialScript();
                break;
            case (1):
                rq1Script();
                break;
            case (2):
                rq2Script();
                break;
            case (3):
                rq3Script();
                break;
            default:
                System.out.println("Invalid script number");
        }
        System.out.println("Success");

    }

    private static void initialScript() {
        Scanner reader = new Scanner(System.in);

        Parser.parse("csvFileInputOutput/SurveyResultsFinal.csv");

        BufferedReader in;
        try {
            in = new BufferedReader(new FileReader(new File("initialScript/output/cleanedData.csv")));
            ResultsStore store = new ResultsStore();
            int sum = 0;
            String line;
            while ((line = in.readLine()) != null) {
                String[] data = line.split(",");
                for (int i = 1; i < data.length; i += 2)
                store.add(data[i], data[i+1]);
                sum++;
            }
            store.writeResults();
            FinalResultsTranslator.generateResults();
        } catch (Exception e) {
            System.out.println("Error running script");
            System.out.println(e);
            exit(1);
        }
    }

    private static void rq1Script() {
        Rq1ResultsGenerator rg = new Rq1ResultsGenerator();
        rg.analyzeData();
    }

    private static void rq2Script() {
        Rq2ResultsGenerator rg = new Rq2ResultsGenerator();
        rg.analyzeData2();
    }

    private static void rq3Script() {
        Rq3ResultsGenerator rg = new Rq3ResultsGenerator();
        rg.analyzeData();
    }
}
