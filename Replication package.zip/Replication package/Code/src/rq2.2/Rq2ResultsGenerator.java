package rq2;

import rq2.DataParser;
import rq2.RuleGroups;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.*;

import static java.lang.System.exit;

public class Rq2ResultsGenerator {
    private Iterator files = DataParser.getIterator();
    private RuleGroups rules = new RuleGroups();

    public void analyzeData1() {
        BufferedReader in;
        PrintWriter writer;

        try {
            writer = new PrintWriter("rq2/Rq2Results.csv", "UTF-8");
            writer.println("Project ID,Version,File Name,Yes,No,Total Lines Touched");

            double yesSmells, noSmells;
            while (files.hasNext()) {
                // Analyze file csvFileData
                String fileName = (String)files.next();
                System.out.println(fileName);
                in = new BufferedReader(new FileReader(new File("csvFileData/" + fileName + ".csv")));

                String line = in.readLine(); // skips headers
                while ((line = in.readLine()) != null) {
                    String[] splitLine = line.split(",");
                    yesSmells = generateSums(splitLine, "yes");
                    noSmells = generateSums(splitLine, "no");

                    writer.println(fileName + "," + splitLine[1] + "," + splitLine[0] + "," + yesSmells + "," + noSmells + "," + splitLine[16]);
                }
            }

            writer.close();
        } catch (Exception e) {
            System.out.println("Error analyzing csvFileData and writing results");
            System.out.println(e);
            exit(1);
        }
    }

    public void analyzeData2() {
        BufferedReader in;
        PrintWriter writer;

        try {
            writer = new PrintWriter("rq2/Rq2Results2.csv", "UTF-8");
            writer.println("Project ID,Version,Yes,No,Total Lines Touched");

            String projectId = null, version = null;
            double yesSmells = 0.0, noSmells = 0.0;
            int totalLinesTouched = 0;
            // Analyze file csvFileData
            in = new BufferedReader(new FileReader(new File("rq2/Rq2Results.csv")));

            String line = in.readLine(); // skips headers
            while ((line = in.readLine()) != null) {
                String[] splitLine = line.split(",");
                if (projectId == null & version == null ) {
                    projectId = splitLine[0];
                    version = splitLine[1];
                }

                if (!projectId.equals(splitLine[0]) || !version.equals(splitLine[1])) {
                    writer.println(projectId + "," + version + "," + yesSmells + "," + noSmells + ","  + totalLinesTouched);

                    projectId = splitLine[0];
                    version = splitLine[1];
                    yesSmells = Double.valueOf(splitLine[3]);
                    noSmells = Double.valueOf((splitLine[4]));
                    totalLinesTouched = Integer.valueOf((splitLine[5].substring(1,splitLine[5].length() - 1)));
                } else {
                    yesSmells += Double.valueOf(splitLine[3]);
                    noSmells += Double.valueOf(splitLine[4]);
                    totalLinesTouched += Integer.valueOf((splitLine[5].substring(1,splitLine[5].length() - 1)));

                }

            }

            writer.close();
        } catch (Exception e) {
            System.out.println("Error analyzing csvFileData and writing results");
            System.out.println(e);
            exit(1);
        }
    }

    private double generateSums(String[] line, String group) {
        int start = 18, stop = 332;
        List<String> groupRulesList = group.equals("yes") ? rules.getYesGroup() : rules.getNoGroup();
        Double sum = 0.0;

        for (int i = start; i <= stop; i++) {
            double val = Double.valueOf(line[i].substring(1, line[i].length() - 1));

            if (groupRulesList.contains(rules.getRulesList().get(i - 18))) {
                sum += val;
            }
        }

        return sum;
    }
}