package rq2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.lang.System.exit;

public class RuleGroups {
    private List<String> rulesList = new ArrayList<>();
    private Map<String, RuleInfo> rules = new HashMap<>();
    private Map<String, List<String>> ruleGroups = new HashMap<>();

    public RuleGroups() {
        try {
            BufferedReader in = new BufferedReader(new FileReader(new File("csvFileInputOutput/ResultsFinal.csv")));

            String line = in.readLine(); // skips column titles
            while ((line = in.readLine()) != null) {
                String[] splitLine = line.split(",");
                RuleInfo ri = new RuleInfo(splitLine);
                rules.put(splitLine[0], ri);
                rulesList.add(splitLine[0]);

                if (!ruleGroups.containsKey(splitLine[2])) {
                    ruleGroups.put(splitLine[2], new ArrayList<>());
                }
                ruleGroups.get(splitLine[2]).add(splitLine[0]);
            }
        } catch (Exception e) {
            System.out.println("Error reading rule groups");
            System.out.println(e);
            exit(1);
        }
    }

    public List<String> getRulesList() {
        return rulesList;
    }

    public List<String> getYesGroup() {
        return ruleGroups.get("yes");
    }

    public List<String> getNoGroup() { return ruleGroups.get("no"); }

    public class RuleInfo {
        String projectId, ruleId, resultId;

        public RuleInfo(String[] info) throws Exception {
            if (info.length != 3) {
                throw new Exception("Invalid rule info given");
            }
            this.projectId = info[0];
            this.ruleId = info[1];
            this.resultId = info[2];
        }
    }
}
