package initialScript;

public class Result {

}
