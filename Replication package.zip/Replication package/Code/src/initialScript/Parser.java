package initialScript;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.lang.System.exit;

public class Parser {
    public static void parse(String fileName) {
        BufferedReader in;
        PrintWriter writer;
        try {
            in = new BufferedReader(new FileReader(new File(fileName)));
            writer = new PrintWriter("initialScript/output/cleanedData.csv", "UTF-8");

            String line = in.readLine(); // skips column titles
            line = in.readLine(); // skips empty row
            while ((line = in.readLine()) != null) {
                String[] splitLine = line.split(",");
                String cleanedLine = cleanLine(splitLine);
                if (cleanedLine != null) {
                    writer.print(splitLine[0] + ",");
                    writer.println(cleanedLine);
                }
            }
            in.close();
            writer.close();
        } catch (Exception e) {
            System.out.println("Error parsing file");
            System.out.println(e);
            exit(1);
        }
    }

    private static String cleanLine(String[] line) {
        String clean = "", rule, response;
        for (int i = 0; i < line.length; i++) {
            if ((rule = getRuleCode(line[i])) != null) {
                response = getResponse(line[++i]);
                clean += "S" + rule + "," + response + ",";
                //clean += rule + "," + response + ",";
            }
        }
        return clean.equals("") ? null : clean;
    }

    private static String getRuleCode(String str) {
        int start = str.indexOf("RSPEC-");
        if (start < 0) {
            return null;
        }
        start += 6;
        String code = "";
        while (Character.isDigit(str.charAt(start))) {
            code += str.charAt(start);
            start++;
        }
        return code;
    }

    private static String getResponse(String str) {
        List<String> validResponses = new ArrayList<>(
                Arrays.asList("Strongly Disagree", "Disagree", "Neutral / I don't know", "Agree", "Strongly Agree"));
        for (String r : validResponses) {
            if (str.equals(r)) {
                return r;
            }
        }
        return null;
    }
}
