package initialScript;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.lang.System.exit;

public class ResultsStore {
    private Map<String, Result> map = new HashMap<>();
    private List<String> keys = new ArrayList<>();

    public void add(String surveyId, String resultsId) {
        try {
            if (map.containsKey(surveyId)) {
                map.get(surveyId).add(resultsId);
            } else {
                Result newResult = new Result(surveyId, resultsId);
                map.put(surveyId, newResult);
                keys.add(surveyId);
            }
        } catch (Exception e) {
            System.out.print("Error adding to results store: ");
            System.out.println(surveyId + ", " + resultsId);
            System.out.println(e);
            exit(1);
        }
    }

    public void writeResults() {
        PrintWriter writer;
        try {
            writer = new PrintWriter("initialScript/output/results.csv", "UTF-8");
            Result r;
            writer.println("Rules,Strongly Disagree,Disagree,Neutral / I don't know,Agree,Strongly Agree,Total\n");
            for (String key : keys) {
                r = map.get(key);
                writer.println(key + "," + r.StronglyDisagree + ","
                        + r.Disagree + "," + r.Neutral + ","
                        + r.Agree + "," + r.StronglyAgree + "," + r.total + ",");
            }
            writer.close();
        } catch (Exception e) {
            System.out.println("Error writing results");
            System.out.println(e);
            exit(1);
        }
    }

    private class Result {
        String surveyId;
        int total = 0, StronglyDisagree = 0, Disagree = 0, Neutral = 0, Agree = 0, StronglyAgree = 0;

        public Result(String surveyId, String resultsId) throws Exception{
            this.surveyId = surveyId;

            add(resultsId);
        }

        public void add(String resultsId) throws Exception {
            if (resultsId.equals("Strongly Disagree")) {
                StronglyDisagree++;
            } else if (resultsId.equals("Disagree")) {
                Disagree++;
            } else if (resultsId.equals("Neutral / I don't know")) {
                Neutral++;
            } else if (resultsId.equals("Agree")) {
                Agree++;
            } else if (resultsId.equals("Strongly Agree")) {
                StronglyAgree++;
            } else {
                System.out.println(resultsId);
                throw new Exception("Invalid Result ID");
            }
            total++;
        }
    }

}