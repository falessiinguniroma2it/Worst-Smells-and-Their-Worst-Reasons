package initialScript;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.*;

import static java.lang.System.exit;

public class FinalResultsTranslator {
    private static List<String> allRules;
    private static Map<String, String> projectIds = new HashMap<>();
    private static Map<String, String> surveyResultIds = new HashMap<>();
    private static Map<String, String> resultIds = new HashMap<>();

    public static void generateResults() {
        setup();
        generateResultsFinal();
    }

    public static void setup() {
        BufferedReader in;
        try {
            generateProjectIdsMap();
            in = new BufferedReader(new FileReader(new File("initialScript/output/results.csv")));
            String line = in.readLine(); // skips column titles
            line = in.readLine(); // skips empty row
            while ((line = in.readLine()) != null) {
                String[] splitLine = line.split(",");
                String data = (projectIds.get(splitLine[0]) + ",");
                if (splitLine[1].equals("0") && splitLine[2].equals("0") && Integer.valueOf(splitLine[4])+Integer.valueOf(splitLine[5]) >= 1) {
                    for (int i = 0; i < splitLine.length; i++) {
                        data += (splitLine[i] + ",");
                    }
                    surveyResultIds.put(splitLine[0], data);
                    resultIds.put(splitLine[0], projectIds.get(splitLine[0]) + "," + splitLine[0] + ",yes,");
                } else {
                    for (int i = 0; i < splitLine.length; i++) {
                        data += (splitLine[i] + ",");
                    }
                    surveyResultIds.put(splitLine[0], data);
                    resultIds.put(splitLine[0], projectIds.get(splitLine[0]) + "," + splitLine[0] + ",no,");
                }
            }
            in.close();
        } catch (Exception e) {
            System.out.println("Error parsing results.csv file");
            System.out.println(e);
            exit(1);
        }
    }

    private static void generateResultsFinal() {
        BufferedReader in;
        PrintWriter writer1, writer2;
        try {
            in = new BufferedReader(new FileReader(new File("csvFileInputOutput/dummyResults.csv")));
            writer1 = new PrintWriter("initialScript/output/ScriptResults.csv", "UTF-8");
            writer2 = new PrintWriter("csvFileInputOutput/ResultsFinal.csv", "UTF-8");
            writer1.println("Project ID,Survey ID,Strongly Disagree,Disagree,Neutral / I don't know,Agree,Strongly Agree,Total\n");
            writer2.println("Projects ID,Survey ID, Results ID");

            String line = in.readLine(); // skips column titles
            while ((line = in.readLine()) != null) {
                String[] splitLine = line.split(",");
                String rule = splitLine[1];

                if (surveyResultIds.containsKey(rule)) {
                    writer1.println(surveyResultIds.get(rule));
                    writer2.println(resultIds.get(rule));

                } else {
                    writer1.println(projectIds.get(rule) + "," + rule + ",-1,-1,-1,-1,-1,-1,");
                    writer2.println(projectIds.get(rule) + "," + rule + ",no,");
                }
            }

            in.close();
            writer1.close();
            writer2.close();
        } catch (Exception e) {
            System.out.println("Error generating results files");
            System.out.println(e);
            exit(1);
        }
    }

    private static void generateProjectIdsMap() {
        BufferedReader in;
        try {
            in = new BufferedReader(new FileReader(new File("csvFileInputOutput/dummyResults.csv")));

            String line = in.readLine(); // skips column titles
            while ((line = in.readLine()) != null) {
                String[] splitLine = line.split(",");
                //String rule = splitLine[1].charAt(0) == 'S' ? splitLine[1].substring(1) : splitLine[1];
                projectIds.put(splitLine[1], splitLine[0]);
            }
            allRules = new ArrayList<>(projectIds.keySet());
            Collections.sort(allRules);
        } catch (Exception e) {
            System.out.println("Error generating ProjectIds Map");
            System.out.println(e);
            exit(1);
        }
    }
}
